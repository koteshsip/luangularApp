 export class AppSettings {
    public  LU_HTTP="http"
    public  SERVER_IP="164.164.34.86"
    public  APP_NAME="lujavaapp"
    public  SPORT="8080"
    //public API_ENDPOINT=this.LU_HTTP+'://'+
    //this.SERVER_IP+':'+this.SPORT+'/'+this.APP_NAME+'/';
    public static API_ENDPOINT='http://localhost:8080/lujavaapp/'; 
 }