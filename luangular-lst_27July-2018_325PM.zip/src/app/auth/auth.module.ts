import { NgModule } from '@angular/core';
import { AuthServiceService } from '../service/auth-service.service';

@NgModule({
imports:[],
declarations:[],
exports:[],
providers:[AuthServiceService]
})

export class AuthModule{

    
}