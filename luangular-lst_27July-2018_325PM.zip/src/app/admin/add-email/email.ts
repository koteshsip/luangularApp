export class Email {
  constructor(
    public emailDescription: any,
    public emailType: any,
    public emailSubject: any,
    public emailContent: any,
    public attachmentLink: any
  ) {  }

}