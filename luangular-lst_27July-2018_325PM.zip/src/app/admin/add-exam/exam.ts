export class  Exam  {
  constructor(
  public examId:any,
	public examType:any,
	public user:any,
	public subjectOfTheExam:any,
	public examDate:any,
	public school:any
  ) {  }
}