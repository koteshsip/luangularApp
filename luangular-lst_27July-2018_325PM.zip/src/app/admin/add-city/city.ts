export class City {
  constructor(
    public cityName: string,
    public stateId: any
  ) {  }

}