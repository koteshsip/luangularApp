export class  Drawing   {
  constructor(
	public drawingId:any,
	public drawingCode:any,
	public drawingName:any,
	public drawingType:any,
	public drawingCategory:any,
	public imageUrl:any
  ) {  }
}