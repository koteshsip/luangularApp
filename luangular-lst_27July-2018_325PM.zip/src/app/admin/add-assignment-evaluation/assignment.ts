export class   Assignment   {
  constructor(
		public studentId: any,
    public assignId:any,
    public assignStartDate: any,
    public assignEndDate: any,
    public assignPath: any,
    public marksObtained: any,    
    public reviewComments: any,
    public reviewBy: any,
    public nameOfReviewer: any,
    public insertedBy: any,
    public insertedTime:any,
    public updatedBy: any,
    public updatedTime: any) {  }
}