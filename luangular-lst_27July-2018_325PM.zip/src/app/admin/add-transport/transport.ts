export class Transport {
  constructor(
    public transportId: any,
    public transportName: any,
    public transportType: any,
    public transportPickupTime: any,
    public transportPickupLocation: any,
    public user: any
    
  ) {  }

}