export class ExamDetail{
  constructor(
    public examDetailId: any,
    public exam: any,
    public question: any,
    public examDuration: any,
    public startTime: any,
    public endTime: any,
    public answersFromStudent: any,
    public examScore: any,
    public examResult: any
  ) {  }

}