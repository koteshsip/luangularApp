export class  Purchase {
  constructor(
	public purchaseId:any,
	public purchaseType:any,
	public productDescription:any,
	public iSBNNumber:any,
	public publisherName:any,
	public productPrice:any,
	public quantityPurchased:any,
	public supplierId:any,
    public purchasedOn:any
	
  ) {  }
}