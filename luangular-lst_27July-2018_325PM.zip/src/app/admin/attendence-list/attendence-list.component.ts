import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendence-list',
  templateUrl: './attendence-list.component.html',
  styleUrls: ['./attendence-list.component.css']
})
export class AttendenceListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
