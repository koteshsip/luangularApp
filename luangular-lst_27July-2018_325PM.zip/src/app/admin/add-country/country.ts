export class Country {
  constructor(
    public countryName: string,
  ) {  }

}