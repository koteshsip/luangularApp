export class   Attendence   {
  constructor(
	public attendenceId:any,
	public tblClass:any,
	public user:any,
	public school:any,
	public schoolName:string,
	public attendenceDate:any
  ) {  }
}