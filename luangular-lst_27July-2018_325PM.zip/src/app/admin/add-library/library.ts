export class  Library {
  constructor(
	public libraryId:any,
	public libraryName:String,
	public bookDueDate:any,
	public bookAllotedTo:String,
	public bookType:String,
	public bookCategoery:String,
	public amountToPay:any,
	public user:String
  ) {  }
}