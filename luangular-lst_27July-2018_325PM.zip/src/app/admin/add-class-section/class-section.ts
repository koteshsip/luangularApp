export class  ClassSection  {
  constructor(
		public classId:any,
	public sectionId:any,
  public className:any,
	public academicYear:any,
	public sectionName:any,
	public noOfStudents:any,
	public buildBlockName:any
  ) {  }
}