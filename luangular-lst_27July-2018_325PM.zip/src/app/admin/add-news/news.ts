export class  News {
  constructor(
	public newsId:any,
	public newsType:String,
	public newsDetails:String,
	public  user:String,
	public newsTitle:String,
	public newsAttachment:any
	
  ) {  }
}