export class   Assignment   {
  constructor(
	public assignmentId:any,
	public classId:any,
	public sectionId:any,
	public associateTeacherId:any,
	public assignType:any,
	public subjectId:any,
	public assignStartDate:any,
	public assignDueDate:String,
	public assignActive:any,
	public maxMarks:any,
	public assignPath:any,	
	public assignCreatedBy:any,
	public insertedBy:any
) {  }
}