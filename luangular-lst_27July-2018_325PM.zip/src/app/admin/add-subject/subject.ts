export class Subject {

    constructor(
      public subjectName: string,
      public textBookName: string,
      public textBookPath: string,
      public textBookLink: string,
      public typeOfMaterial: string,
      public subjectMaterialFiletype: string,
      public subjectCoverpage:any,
      public subjectId:any,
      public textBookISBN:any
    ) {  }
  
  }