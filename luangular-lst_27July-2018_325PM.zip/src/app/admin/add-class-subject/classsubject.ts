export class ClassSubject {
    constructor(
      public classId: any,
      public sectionId:any,
      public subjectId:any,
      public subjectName:any,
      public academicYear:any, 
      public teacherId:any,    
      public teacherName:any,

    ) {  }
  
  }