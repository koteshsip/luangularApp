export class  Book   {
  constructor(
	public bookId:any,
	public bookType:any,
	public bookCategory:any,
	public bookName:any,
	public supplierId:any,
	public imageLink:any,
	public newItem:any,
	public tblClass:any
  ) {  }
}