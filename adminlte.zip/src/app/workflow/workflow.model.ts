export const STEPS = {
    profile: 'profile',
    // work: 'work',
    address: 'address',
    user: 'user',
    result: 'result'
}
