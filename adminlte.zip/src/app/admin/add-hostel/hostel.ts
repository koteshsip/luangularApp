export class  Hostel  {
  constructor(
	public hostelId:any,
	public hostelName:any,
	public hostelRoomType:any,
	public totalRoomsAvailable:any,
	public totalRoomsOccupied:any,
	public selectedRoomAvailable:any
  ) {  }
}