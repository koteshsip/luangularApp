export class ResourceBank {
  constructor(
	public resourceBankId:any,
	public resourceName:any,
	public tblClass:any,
	public thumbnailUrl:any,
	public title:any,
	public heading:any,
	public locationPath:any,
	public resourceDocPath:any
  ) {  }
}