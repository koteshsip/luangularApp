import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drawing-list',
  templateUrl: './drawing-list.component.html',
  styleUrls: ['./drawing-list.component.css']
})
export class DrawingListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
