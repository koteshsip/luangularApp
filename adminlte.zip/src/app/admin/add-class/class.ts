export class  TblClass  {
  constructor(
  public classId:any,
	public className:any,
	public section:any,
	public classRoomName:any,
	public classDescription:any
  ) {  }
}