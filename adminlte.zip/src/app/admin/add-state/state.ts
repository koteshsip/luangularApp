export class State {
  constructor(
    public stateName: string,
    public countryId:any
  ) {  }

}