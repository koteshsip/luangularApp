export class TimeTable {
  constructor(
    public tblClass: any,
    public startDate: any,
    public endDate: any,
    public user: any,
    public section: any
  ) {  }

}