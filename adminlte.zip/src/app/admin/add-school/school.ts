export class School {
  constructor(
	public schoolId:any,
	public schoolName:any,
	public address:any,
	public noOfTeachers:any,
	public noOfStudents:any,
	public noOfStaffs:any,
	public noOfSuppliers:any,
	public noOfTransport:any,
	public noOfClasses:any,
	public tblClass:any,
	public user:any,
	public supplier:any,
	public transport:any,
	public departmentCode:any,
	public createdAt:any,
	public updatedAt:any,
	public message:any
  ) {  }
}