export class  Supplier   {
  constructor(
    public supplierId:any,
    public supplierEmail,
	public supplierName:any,
	public address:any,
	public supplierCategory:any
  ) {  }
}